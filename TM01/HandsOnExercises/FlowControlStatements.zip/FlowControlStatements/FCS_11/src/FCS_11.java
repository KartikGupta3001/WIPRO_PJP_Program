
public class FCS_11 {
	public static void main(String args[])
	{
		int i;
		for(i=23;i<57;i+=2)
		{
			System.out.println(i+1);
		}
	}
}
