
public class FCS_10 {
	public static void main(String args[])
	{
		int i;
		for(i=0;i<=9;i++)
		{
			System.out.print((i+1)+"\t");
		}
	}
}
